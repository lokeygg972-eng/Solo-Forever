# ⚔️ Solo Fitness — Hunter System

Application fitness gamifiée inspirée de Solo Leveling. Complète des quêtes quotidiennes, monte en rang et deviens le plus puissant des Hunters.

## Fonctionnalités

- **Système de rang** : E → D → C → B → A → S
- **Quêtes quotidiennes** : 100 pompes, 100 abdos, 100 squats, 10km course
- **Quêtes bonus** : Tractions, planche, méditation, sprints...
- **Stats RPG** : Force, Vitalité, Agilité, Endurance, Volonté
- **Allocation de points** : Gagne des points de stat à chaque level up
- **Titres & succès** : Débloque des achievements en progressant

## Installation locale

```bash
npm install
npm run dev
```

## Déploiement

Le site se déploie automatiquement sur GitHub Pages via GitHub Actions à chaque push sur `main`.
