import React from 'react'
import ReactDOM from 'react-dom/client'
import SoloFitness from './App.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <SoloFitness />
  </React.StrictMode>
)
