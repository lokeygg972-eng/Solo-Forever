import { useState, useEffect, useRef, useCallback } from "react";

/* ─── SVG ICON COMPONENTS ─── */
const Icons = {
  Sword: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14.5 17.5L3 6V3h3l11.5 11.5"/><path d="M13 19l6-6"/><path d="M16 16l4 4"/><path d="M19 21l2-2"/>
    </svg>
  ),
  Shield: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    </svg>
  ),
  Flame: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} stroke="none">
      <path d="M12 23c-3.866 0-7-3.134-7-7 0-3.5 3-7.5 4-9 .667 2 2 3 2 3s1.5-2 2-4c.5-2 0-4 0-4 3 2 6 6.5 6 10 0 5.5-2.5 8-4 9.5.5-1.5.5-3 0-4.5-.5 1.5-1.5 3-3 4z"/>
    </svg>
  ),
  Lightning: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} stroke="none">
      <path d="M13 2L3 14h8l-1 8 10-12h-8l1-8z"/>
    </svg>
  ),
  Heart: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} stroke="none">
      <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
    </svg>
  ),
  Dumbbell: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
      <path d="M6.5 6.5h11M6.5 17.5h11"/><rect x="3" y="5" width="3.5" height="14" rx="1"/><rect x="17.5" y="5" width="3.5" height="14" rx="1"/><rect x="1" y="8" width="2" height="8" rx="0.5"/><rect x="21" y="8" width="2" height="8" rx="0.5"/>
    </svg>
  ),
  Run: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} stroke="none">
      <circle cx="13.5" cy="5.5" r="2.2"/><path d="M10.5 23l1.2-5.5-2.2 1v-4.5l-3.5-3 1.5-2.5 4.5 2.5h3l2 3.5-2.5 1.5-1.5-2-1 5.5 3 3.5-1.5 1z"/>
    </svg>
  ),
  Target: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2">
      <circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>
    </svg>
  ),
  Crown: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} stroke="none">
      <path d="M2 20h20v2H2zM4 18l1-10 5 4 2-8 2 8 5-4 1 10z"/>
    </svg>
  ),
  Skull: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round">
      <circle cx="12" cy="10" r="8"/><circle cx="9" cy="10" r="1.5" fill={color}/><circle cx="15" cy="10" r="1.5" fill={color}/><path d="M10 22v-4M14 22v-4M9 15c1 1.5 5 1.5 6 0"/>
    </svg>
  ),
  Brain: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round">
      <path d="M12 2a5 5 0 00-4.8 3.5A4 4 0 004 9.5a4 4 0 001.5 7A4.5 4.5 0 0012 22a4.5 4.5 0 006.5-5.5 4 4 0 001.5-7 4 4 0 00-3.2-4A5 5 0 0012 2z"/><path d="M12 2v20"/>
    </svg>
  ),
  Stretch: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} stroke="none">
      <circle cx="12" cy="4" r="2.2"/><path d="M15 22l-3-8-3 8h-2l3.5-10L7 9l1-2 4 2 4-2 1 2-3.5 3L17 22z"/>
    </svg>
  ),
  Wind: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
      <path d="M17.7 7.7A2.5 2.5 0 1015 5H3"/><path d="M9.6 4.6A2 2 0 118 3H3"/><path d="M12.6 19.4A2 2 0 1014 21H3"/><path d="M17.7 16.3A2.5 2.5 0 1115 19H3"/>
    </svg>
  ),
  Chair: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
      <rect x="5" y="4" width="14" height="10" rx="2"/><path d="M5 14v6M19 14v6M8 20h8"/>
    </svg>
  ),
  Plank: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
      <path d="M3 16l4-1 10 0 4 1"/><circle cx="5" cy="12" r="1.5"/><path d="M7 13l10 0"/><path d="M19 15v3M3 15v3"/>
    </svg>
  ),
  Home: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
    </svg>
  ),
  Chart: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
      <path d="M18 20V10M12 20V4M6 20v-6"/>
    </svg>
  ),
  Trophy: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 9H4a2 2 0 01-2-2V5h4"/><path d="M18 9h2a2 2 0 002-2V5h-4"/><path d="M4 5h16v5a6 6 0 01-6 6h-4a6 6 0 01-6-6V5z"/><path d="M12 16v3"/><path d="M8 22h8"/><path d="M12 19h0"/>
    </svg>
  ),
  Lock: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round">
      <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/>
    </svg>
  ),
  Check: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12"/>
    </svg>
  ),
  Plus: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="3" strokeLinecap="round">
      <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
    </svg>
  ),
  Star: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} stroke="none">
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"/>
    </svg>
  ),
  Refresh: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/>
    </svg>
  ),
  ArrowUp: ({ size = 22, color = "currentColor" }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/>
    </svg>
  ),
};

/* ─── GAME DATA ─── */
const RANKS = [
  { rank: "E", label: "E-Rank Hunter", color: "#6b7280", glow: "#6b728040", xpReq: 0 },
  { rank: "D", label: "D-Rank Hunter", color: "#22d3ee", glow: "#22d3ee35", xpReq: 500 },
  { rank: "C", label: "C-Rank Hunter", color: "#34d399", glow: "#34d39935", xpReq: 1500 },
  { rank: "B", label: "B-Rank Hunter", color: "#a78bfa", glow: "#a78bfa35", xpReq: 3500 },
  { rank: "A", label: "A-Rank Hunter", color: "#f59e0b", glow: "#f59e0b35", xpReq: 7000 },
  { rank: "S", label: "S-Rank Hunter", color: "#ef4444", glow: "#ef444445", xpReq: 15000 },
];

const STATS_META = [
  { key: "STR", name: "Force", IconComp: Icons.Dumbbell },
  { key: "VIT", name: "Vitalité", IconComp: Icons.Heart },
  { key: "AGI", name: "Agilité", IconComp: Icons.Lightning },
  { key: "END", name: "Endurance", IconComp: Icons.Shield },
  { key: "WIL", name: "Volonté", IconComp: Icons.Flame },
];

const QUESTS = [
  { id: "pushups", name: "100 Pompes", desc: "Complète 100 pompes aujourd'hui", xp: 80, stat: "STR", target: 100, unit: "", IconComp: Icons.ArrowUp, category: "daily" },
  { id: "situps", name: "100 Abdos", desc: "Complète 100 abdominaux", xp: 80, stat: "VIT", target: 100, unit: "", IconComp: Icons.Target, category: "daily" },
  { id: "squats", name: "100 Squats", desc: "Complète 100 squats", xp: 80, stat: "STR", target: 100, unit: "", IconComp: Icons.Dumbbell, category: "daily" },
  { id: "run", name: "Course 10km", desc: "Cours 10 kilomètres", xp: 120, stat: "AGI", target: 10, unit: "km", IconComp: Icons.Run, category: "daily" },
  { id: "plank", name: "Planche 5min", desc: "Tiens la planche 5 minutes", xp: 100, stat: "END", target: 5, unit: "min", IconComp: Icons.Plank, category: "bonus" },
  { id: "pullups", name: "50 Tractions", desc: "Fais 50 tractions", xp: 150, stat: "STR", target: 50, unit: "", IconComp: Icons.Skull, category: "bonus" },
  { id: "meditation", name: "Méditation 20min", desc: "Médite pendant 20 minutes", xp: 80, stat: "WIL", target: 20, unit: "min", IconComp: Icons.Brain, category: "bonus" },
  { id: "stretch", name: "Étirements 15min", desc: "Étire-toi 15 minutes", xp: 60, stat: "AGI", target: 15, unit: "min", IconComp: Icons.Stretch, category: "bonus" },
  { id: "sprint", name: "10 Sprints", desc: "10 sprints de 100m", xp: 130, stat: "AGI", target: 10, unit: "", IconComp: Icons.Wind, category: "bonus" },
  { id: "wall_sit", name: "Chaise 3min", desc: "Tiens la chaise 3 minutes", xp: 90, stat: "END", target: 3, unit: "min", IconComp: Icons.Chair, category: "bonus" },
];

const ACHIEVEMENTS = [
  { id: "first", name: "Premier Pas", desc: "Complète ta première quête", IconComp: Icons.Star, cond: s => s.total >= 1 },
  { id: "ten", name: "Chasseur Assidu", desc: "Complète 10 quêtes", IconComp: Icons.Sword, cond: s => s.total >= 10 },
  { id: "d_rank", name: "Éveil", desc: "Atteins le rang D", IconComp: Icons.Lightning, cond: s => s.ri >= 1 },
  { id: "c_rank", name: "Montée en Puissance", desc: "Atteins le rang C", IconComp: Icons.Shield, cond: s => s.ri >= 2 },
  { id: "b_rank", name: "Élite", desc: "Atteins le rang B", IconComp: Icons.Crown, cond: s => s.ri >= 3 },
  { id: "a_rank", name: "Légende", desc: "Atteins le rang A", IconComp: Icons.Flame, cond: s => s.ri >= 4 },
  { id: "s_rank", name: "Monarque des Ombres", desc: "Atteins le rang S", IconComp: Icons.Skull, cond: s => s.ri >= 5 },
  { id: "power50", name: "Surhumain", desc: "Monte une stat à 50+", IconComp: Icons.Brain, cond: s => Object.values(s.stats).some(v => v >= 50) },
];

/* ─── HELPERS ─── */
function getRankIdx(xp) {
  for (let i = RANKS.length - 1; i >= 0; i--) if (xp >= RANKS[i].xpReq) return i;
  return 0;
}

/* ─── PARTICLE CANVAS ─── */
function Particles({ color }) {
  const ref = useRef(null);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext("2d");
    let raf;
    const resize = () => { c.width = c.offsetWidth * 1.5; c.height = c.offsetHeight * 1.5; };
    resize(); window.addEventListener("resize", resize);
    const pts = Array.from({ length: 50 }, () => ({
      x: Math.random(), y: Math.random(),
      vy: -(Math.random() * 0.0008 + 0.0003),
      s: Math.random() * 2 + 0.5,
      a: Math.random() * 0.5 + 0.15,
    }));
    const draw = () => {
      ctx.clearRect(0, 0, c.width, c.height);
      for (const p of pts) {
        p.y += p.vy;
        if (p.y < -0.02) { p.y = 1.02; p.x = Math.random(); }
        ctx.beginPath();
        ctx.arc(p.x * c.width, p.y * c.height, p.s, 0, 6.28);
        ctx.fillStyle = color + Math.round(p.a * 255).toString(16).padStart(2, "0");
        ctx.fill();
      }
      raf = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, [color]);
  return <canvas ref={ref} style={{ position: "fixed", inset: 0, width: "100%", height: "100%", pointerEvents: "none", zIndex: 0, opacity: 0.7 }} />;
}

/* ─── NOTIFICATION ─── */
function Toast({ msg, visible }) {
  return (
    <div style={{
      position: "fixed", top: 24, left: "50%", transform: `translateX(-50%) translateY(${visible ? 0 : -100}px)`,
      background: "#14142acc", border: "1px solid #a78bfa44", backdropFilter: "blur(16px)",
      borderRadius: 14, padding: "13px 26px", zIndex: 9999, transition: "all 0.45s cubic-bezier(.36,1.56,.64,1)",
      opacity: visible ? 1 : 0, boxShadow: "0 12px 40px #0006",
      fontFamily: "'Cinzel', serif", color: "#d4c8f0", fontSize: "0.9rem", letterSpacing: "0.06em",
      pointerEvents: "none", textAlign: "center", whiteSpace: "nowrap",
    }}>{msg}</div>
  );
}

/* ─── MAIN APP ─── */
export default function SoloFitness() {
  const [data, setData] = useState(() => {
    try { const s = JSON.parse(localStorage.getItem("sf4")); if (s) return s; } catch {}
    return null;
  });
  const [page, setPage] = useState("hub");
  const [toast, setToast] = useState({ msg: "", show: false });
  const [rankUp, setRankUp] = useState(null);
  const [inputs, setInputs] = useState({});
  const [nameInput, setNameInput] = useState("");
  const timerRef = useRef(null);

  const save = useCallback((d) => {
    try { localStorage.setItem("sf4", JSON.stringify(d)); } catch {}
  }, []);

  const notify = useCallback((msg) => {
    clearTimeout(timerRef.current);
    setToast({ msg, show: true });
    timerRef.current = setTimeout(() => setToast(t => ({ ...t, show: false })), 2800);
  }, []);

  /* ─ Create character ─ */
  const create = () => {
    if (!nameInput.trim()) return;
    const d = {
      name: nameInput.trim(), xp: 0, level: 1,
      stats: { STR: 5, VIT: 5, AGI: 5, END: 5, WIL: 5 },
      progress: {}, done: [], totalDone: 0, sp: 0,
    };
    setData(d);
    save(d);
    notify("Bienvenue, Hunter " + nameInput.trim());
  };

  /* ─ Intro screen ─ */
  if (!data) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#08081a", fontFamily: "'Cinzel', serif" }}>
        <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700;900&family=Rajdhani:wght@400;500;600;700&display=swap" rel="stylesheet" />
        <Particles color="#6366f1" />
        <div style={{
          position: "relative", zIndex: 1, borderRadius: 24, width: "min(420px, 90vw)",
          background: "linear-gradient(160deg, #12122e, #18183a)", border: "1px solid #ffffff08",
          padding: "56px 40px", textAlign: "center",
          boxShadow: "0 30px 80px #0008, inset 0 1px 0 #ffffff06",
        }}>
          <div style={{ marginBottom: 16 }}><Icons.Sword size={48} color="#818cf8" /></div>
          <h1 style={{ fontSize: "1.8rem", fontWeight: 900, color: "#818cf8", letterSpacing: "0.14em", textShadow: "0 0 30px #818cf855", margin: "0 0 6px" }}>
            SOLO FITNESS
          </h1>
          <p style={{ color: "#7a7aa0", fontFamily: "'Rajdhani', sans-serif", fontSize: "0.95rem", margin: "0 0 36px", letterSpacing: "0.06em" }}>
            Deviens le plus puissant des Hunters
          </p>
          <input
            value={nameInput} onChange={e => setNameInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && create()}
            placeholder="Nom du Hunter..."
            style={{
              width: "100%", padding: "15px 18px", fontSize: "1rem", borderRadius: 12,
              background: "#0c0c20", border: "1px solid #2a2a55", color: "#d0d0f0",
              fontFamily: "'Rajdhani', sans-serif", outline: "none", boxSizing: "border-box",
              letterSpacing: "0.04em", transition: "border 0.2s",
            }}
            onFocus={e => e.target.style.borderColor = "#6366f1"}
            onBlur={e => e.target.style.borderColor = "#2a2a55"}
          />
          <button onClick={create} style={{
            width: "100%", padding: "15px", marginTop: 16, fontSize: "1rem", fontFamily: "'Cinzel', serif",
            fontWeight: 700, borderRadius: 12, border: "none", cursor: "pointer",
            background: "linear-gradient(135deg, #4f46e5, #7c3aed)", color: "#fff",
            letterSpacing: "0.14em", textTransform: "uppercase",
            boxShadow: "0 6px 24px #4f46e544", transition: "transform 0.15s, box-shadow 0.15s",
          }}
            onMouseDown={e => e.target.style.transform = "scale(0.97)"}
            onMouseUp={e => e.target.style.transform = ""}
          >
            Commencer l'Éveil
          </button>
        </div>
      </div>
    );
  }

  /* ─ Game state derivations ─ */
  const ri = getRankIdx(data.xp);
  const rank = RANKS[ri];
  const nextRank = RANKS[Math.min(ri + 1, RANKS.length - 1)];
  const xpInRank = data.xp - rank.xpReq;
  const xpForNext = nextRank.xpReq - rank.xpReq;
  const isMax = ri === RANKS.length - 1;
  const totalPower = Object.values(data.stats).reduce((a, b) => a + b, 0);

  /* ─ Core actions ─ */
  const addProgress = (qid, amount) => {
    if (amount <= 0) return;
    const q = QUESTS.find(x => x.id === qid);
    if (!q || data.done.includes(qid)) return;
    const cur = (data.progress[qid] || 0) + amount;
    const nd = { ...data, progress: { ...data.progress, [qid]: Math.min(cur, q.target * 2) } };
    setData(nd);
    save(nd);
    setInputs(prev => ({ ...prev, [qid]: "" }));
  };

  const validateQuest = (qid) => {
    const q = QUESTS.find(x => x.id === qid);
    if (!q) return;
    const cur = data.progress[qid] || 0;
    if (cur < q.target || data.done.includes(qid)) return;

    const oldRi = getRankIdx(data.xp);
    const newXP = data.xp + q.xp;
    const newStats = { ...data.stats, [q.stat]: data.stats[q.stat] + Math.ceil(q.xp / 25) };
    const newLevel = Math.floor(newXP / 200) + 1;
    const lvlUps = newLevel - data.level;
    const nd = {
      ...data, xp: newXP, stats: newStats, level: newLevel,
      done: [...data.done, qid], totalDone: data.totalDone + 1,
      sp: data.sp + lvlUps * 2,
    };
    setData(nd);
    save(nd);

    const newRi = getRankIdx(newXP);
    if (newRi > oldRi) {
      setTimeout(() => {
        setRankUp(RANKS[newRi]);
        setTimeout(() => setRankUp(null), 3200);
      }, 200);
    }

    notify("Quête terminée : " + q.name + " — +" + q.xp + " XP");
  };

  const allocStat = (key) => {
    if (data.sp <= 0) return;
    const nd = { ...data, stats: { ...data.stats, [key]: data.stats[key] + 1 }, sp: data.sp - 1 };
    setData(nd);
    save(nd);
  };

  const resetDay = () => {
    const nd = { ...data, progress: {}, done: [] };
    setData(nd);
    save(nd);
    setInputs({});
    notify("Nouvelles quêtes quotidiennes !");
  };

  /* ─ Styles ─ */
  const bg = `linear-gradient(170deg, #08081a 0%, ${rank.color}08 50%, #08081a 100%)`;
  const card = { background: "#ffffff05", border: "1px solid #ffffff08", borderRadius: 16, padding: 20, marginBottom: 14, backdropFilter: "blur(8px)" };

  const dailyQuests = QUESTS.filter(q => q.category === "daily");
  const bonusQuests = QUESTS.filter(q => q.category === "bonus");
  const dailyDone = dailyQuests.filter(q => data.done.includes(q.id)).length;

  const navItems = [
    { id: "hub", label: "Hub", Ic: Icons.Home },
    { id: "quests", label: "Quêtes", Ic: Icons.Sword },
    { id: "stats", label: "Stats", Ic: Icons.Chart },
    { id: "titles", label: "Titres", Ic: Icons.Trophy },
  ];

  /* ─ Quest card renderer ─ */
  const QuestCard = ({ q, accentColor }) => {
    const done = data.done.includes(q.id);
    const cur = data.progress[q.id] || 0;
    const pct = Math.min(cur / q.target, 1);
    const ready = pct >= 1 && !done;
    const IC = q.IconComp;
    return (
      <div style={{
        ...card, opacity: done ? 0.45 : 1,
        border: ready ? `1px solid ${accentColor}55` : done ? "1px solid #22c55e22" : "1px solid #ffffff08",
        transition: "all 0.3s",
      }}>
        <div style={{ display: "flex", gap: 14 }}>
          <div style={{
            width: 48, height: 48, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center",
            background: `${accentColor}12`, border: `1px solid ${accentColor}20`, flexShrink: 0,
          }}>
            <IC size={24} color={accentColor} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
              <span style={{ fontWeight: 700, fontSize: "0.95rem", fontFamily: "'Cinzel', serif" }}>{q.name}</span>
              <span style={{
                fontSize: "0.7rem", padding: "3px 9px", borderRadius: 8, whiteSpace: "nowrap",
                background: `${accentColor}18`, color: accentColor, fontWeight: 700, letterSpacing: "0.04em",
              }}>+{q.xp} XP · {q.stat}</span>
            </div>
            <p style={{ fontSize: "0.82rem", color: "#8888aa", margin: "5px 0 10px", lineHeight: 1.3 }}>{q.desc}</p>

            {/* Progress bar */}
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ flex: 1, height: 7, borderRadius: 4, background: "#ffffff08", overflow: "hidden" }}>
                <div style={{
                  height: "100%", borderRadius: 4, width: `${pct * 100}%`,
                  background: done ? "#22c55e" : `linear-gradient(90deg, ${accentColor}77, ${accentColor})`,
                  transition: "width 0.5s cubic-bezier(.4,0,.2,1)",
                  boxShadow: pct > 0 ? `0 0 8px ${accentColor}44` : "none",
                }} />
              </div>
              <span style={{ fontSize: "0.78rem", color: "#8888aa", minWidth: 55, textAlign: "right", fontWeight: 600 }}>
                {Math.min(cur, q.target)}/{q.target}{q.unit}
              </span>
            </div>

            {/* Input & buttons */}
            {!done && (
              <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                <input
                  type="number" inputMode="numeric" min="0" placeholder="0"
                  value={inputs[q.id] ?? ""}
                  onChange={e => setInputs({ ...inputs, [q.id]: e.target.value })}
                  onKeyDown={e => { if (e.key === "Enter") { addProgress(q.id, Number(inputs[q.id]) || 0); } }}
                  style={{
                    flex: 1, padding: "10px 14px", borderRadius: 10, border: "1px solid #ffffff12",
                    background: "#0a0a1e", color: "#d0d0f0", fontSize: "0.95rem",
                    fontFamily: "'Rajdhani', sans-serif", outline: "none", minWidth: 0,
                    transition: "border 0.2s",
                  }}
                  onFocus={e => e.target.style.borderColor = accentColor + "66"}
                  onBlur={e => e.target.style.borderColor = "#ffffff12"}
                />
                <button onClick={() => addProgress(q.id, Number(inputs[q.id]) || 0)} style={{
                  width: 44, height: 44, borderRadius: 10, border: "none", cursor: "pointer",
                  background: `linear-gradient(135deg, ${accentColor}cc, ${accentColor})`, display: "flex", alignItems: "center", justifyContent: "center",
                  boxShadow: `0 4px 14px ${accentColor}33`, transition: "transform 0.1s",
                }}
                  onMouseDown={e => e.currentTarget.style.transform = "scale(0.92)"}
                  onMouseUp={e => e.currentTarget.style.transform = ""}
                >
                  <Icons.Plus size={20} color="#fff" />
                </button>
                {ready && (
                  <button onClick={() => validateQuest(q.id)} style={{
                    padding: "0 18px", height: 44, borderRadius: 10, border: "none", cursor: "pointer",
                    background: "linear-gradient(135deg, #16a34a, #22c55e)", display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                    boxShadow: "0 4px 14px #22c55e33", fontFamily: "'Rajdhani', sans-serif", fontWeight: 700,
                    fontSize: "0.85rem", color: "#fff", letterSpacing: "0.06em", transition: "transform 0.1s",
                  }}
                    onMouseDown={e => e.currentTarget.style.transform = "scale(0.92)"}
                    onMouseUp={e => e.currentTarget.style.transform = ""}
                  >
                    <Icons.Check size={16} color="#fff" /> VALIDER
                  </button>
                )}
              </div>
            )}
            {done && (
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 10, color: "#22c55e", fontWeight: 700, fontSize: "0.85rem" }}>
                <Icons.Check size={16} color="#22c55e" /> Complétée
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div style={{ minHeight: "100vh", background: bg, fontFamily: "'Rajdhani', sans-serif", color: "#d0d0ee", position: "relative" }}>
      <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700;900&family=Rajdhani:wght@400;500;600;700&display=swap" rel="stylesheet" />
      <Particles color={rank.color} />
      <Toast msg={toast.msg} visible={toast.show} />

      {/* Rank Up overlay */}
      {rankUp && (
        <div style={{
          position: "fixed", inset: 0, zIndex: 9998, display: "flex", alignItems: "center", justifyContent: "center",
          background: "#000000dd", animation: "fadeIn 0.3s",
        }}>
          <div style={{ textAlign: "center", animation: "popIn 0.55s cubic-bezier(.36,1.56,.64,1)" }}>
            <Icons.Crown size={72} color={rankUp.color} />
            <h2 style={{
              fontFamily: "'Cinzel', serif", fontSize: "2.8rem", fontWeight: 900, color: rankUp.color,
              textShadow: `0 0 40px ${rankUp.glow}, 0 0 80px ${rankUp.glow}`, margin: "16px 0 8px",
              letterSpacing: "0.18em",
            }}>RANK UP</h2>
            <p style={{ fontFamily: "'Cinzel', serif", fontSize: "1.3rem", color: rankUp.color + "cc", letterSpacing: "0.1em" }}>
              {rankUp.label}
            </p>
          </div>
        </div>
      )}

      {/* Header */}
      <header style={{
        position: "relative", zIndex: 2, padding: "18px 18px 14px",
        background: "linear-gradient(180deg, #000000aa, transparent)",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 13, maxWidth: 540, margin: "0 auto" }}>
          <div style={{
            width: 52, height: 52, borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center",
            background: `linear-gradient(135deg, ${rank.color}22, ${rank.color}08)`,
            border: `2px solid ${rank.color}55`, boxShadow: `0 0 20px ${rank.glow}`,
            fontFamily: "'Cinzel', serif", fontWeight: 900, fontSize: "1.3rem", color: rank.color,
          }}>
            {rank.rank}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: "1.05rem", color: rank.color }}>
              {data.name}
            </div>
            <div style={{ fontSize: "0.78rem", color: "#7a7aa0", letterSpacing: "0.04em" }}>
              {rank.label} · Lv.{data.level} · Puissance {totalPower}
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: "0.7rem", color: "#7a7aa0", letterSpacing: "0.06em" }}>XP</div>
            <div style={{ fontSize: "1.1rem", fontWeight: 700, color: rank.color, fontFamily: "'Cinzel', serif" }}>{data.xp.toLocaleString()}</div>
          </div>
        </div>
        {!isMax && (
          <div style={{ maxWidth: 540, margin: "10px auto 0" }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.68rem", color: "#7a7aa0", marginBottom: 5 }}>
              <span style={{ fontWeight: 700, color: rank.color }}>{rank.rank}</span>
              <span>{xpInRank} / {xpForNext}</span>
              <span style={{ fontWeight: 700, color: nextRank.color }}>{nextRank.rank}</span>
            </div>
            <div style={{ height: 6, borderRadius: 3, background: "#ffffff08", overflow: "hidden" }}>
              <div style={{
                height: "100%", borderRadius: 3,
                width: `${Math.min((xpInRank / Math.max(xpForNext, 1)) * 100, 100)}%`,
                background: `linear-gradient(90deg, ${rank.color}, ${nextRank.color})`,
                boxShadow: `0 0 10px ${rank.color}55`, transition: "width 0.7s cubic-bezier(.4,0,.2,1)",
              }} />
            </div>
          </div>
        )}
      </header>

      {/* Pages */}
      <main style={{ position: "relative", zIndex: 1, padding: "10px 16px 110px", maxWidth: 540, margin: "0 auto" }}>

        {/* ─── HUB ─── */}
        {page === "hub" && <>
          <div style={{ textAlign: "center", margin: "18px 0 24px" }}>
            <h2 style={{ fontFamily: "'Cinzel', serif", fontWeight: 900, fontSize: "1.5rem", color: rank.color, letterSpacing: "0.14em", textShadow: `0 0 24px ${rank.glow}`, margin: 0 }}>
              HUNTER HUB
            </h2>
          </div>

          {/* Daily summary */}
          <div style={{ ...card, background: `linear-gradient(145deg, ${rank.color}08, transparent)`, borderColor: `${rank.color}18` }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <span style={{ fontFamily: "'Cinzel', serif", fontWeight: 700 }}>Quêtes du Jour</span>
              <span style={{ color: rank.color, fontWeight: 700, fontSize: "1.1rem" }}>{dailyDone}/{dailyQuests.length}</span>
            </div>
            {dailyQuests.map(q => {
              const done = data.done.includes(q.id);
              const cur = data.progress[q.id] || 0;
              const pct = Math.min(cur / q.target, 1);
              const IC = q.IconComp;
              return (
                <div key={q.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "9px 0", borderBottom: "1px solid #ffffff06", opacity: done ? 0.4 : 1 }}>
                  <IC size={20} color={done ? "#22c55e" : rank.color} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "0.85rem", fontWeight: 600 }}>{q.name}</div>
                    <div style={{ height: 4, borderRadius: 2, background: "#ffffff08", marginTop: 4, overflow: "hidden" }}>
                      <div style={{ height: "100%", borderRadius: 2, width: `${pct * 100}%`, background: done ? "#22c55e" : rank.color, transition: "width 0.4s" }} />
                    </div>
                  </div>
                  {done ? <Icons.Check size={16} color="#22c55e" /> : <span style={{ fontSize: "0.75rem", color: "#7a7aa0" }}>+{q.xp}</span>}
                </div>
              );
            })}
            <button onClick={() => setPage("quests")} style={{
              width: "100%", marginTop: 16, padding: "13px", borderRadius: 12, border: "none", cursor: "pointer",
              background: `linear-gradient(135deg, ${rank.color}cc, ${rank.color})`, color: "#fff",
              fontFamily: "'Cinzel', serif", fontWeight: 700, fontSize: "0.9rem", letterSpacing: "0.1em",
              boxShadow: `0 4px 18px ${rank.color}33`, transition: "transform 0.1s",
            }}
              onMouseDown={e => e.target.style.transform = "scale(0.97)"}
              onMouseUp={e => e.target.style.transform = ""}
            >
              VOIR TOUTES LES QUÊTES
            </button>
          </div>

          {/* Stats grid */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 14 }}>
            {STATS_META.map(({ key, name, IconComp }) => (
              <div key={key} style={{ ...card, marginBottom: 0, textAlign: "center", padding: "14px 8px" }}>
                <IconComp size={22} color={rank.color} />
                <div style={{ fontSize: "0.68rem", color: "#7a7aa0", marginTop: 5, letterSpacing: "0.06em" }}>{name}</div>
                <div style={{ fontSize: "1.3rem", fontWeight: 700, color: rank.color, fontFamily: "'Cinzel', serif" }}>{data.stats[key]}</div>
              </div>
            ))}
          </div>

          <button onClick={resetDay} style={{
            width: "100%", padding: "13px", borderRadius: 12, border: "1px solid #ef444433", cursor: "pointer",
            background: "#ef444412", color: "#ef4444",
            fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: "0.9rem", letterSpacing: "0.08em",
            display: "flex", alignItems: "center", justifyContent: "center", gap: 8, transition: "background 0.2s",
          }}
            onMouseEnter={e => e.currentTarget.style.background = "#ef444422"}
            onMouseLeave={e => e.currentTarget.style.background = "#ef444412"}
          >
            <Icons.Refresh size={18} color="#ef4444" /> RESET QUOTIDIEN
          </button>
        </>}

        {/* ─── QUESTS ─── */}
        {page === "quests" && <>
          <div style={{ textAlign: "center", margin: "18px 0 24px" }}>
            <h2 style={{ fontFamily: "'Cinzel', serif", fontWeight: 900, fontSize: "1.5rem", color: rank.color, letterSpacing: "0.14em", textShadow: `0 0 24px ${rank.glow}`, margin: 0 }}>
              QUÊTES
            </h2>
          </div>

          <div style={{ fontSize: "0.75rem", color: rank.color, fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase", marginBottom: 12, display: "flex", alignItems: "center", gap: 8 }}>
            <Icons.Sword size={16} color={rank.color} /> QUOTIDIENNES
          </div>
          {dailyQuests.map(q => <QuestCard key={q.id} q={q} accentColor={rank.color} />)}

          <div style={{ fontSize: "0.75rem", color: "#f59e0b", fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase", margin: "24px 0 12px", display: "flex", alignItems: "center", gap: 8 }}>
            <Icons.Star size={16} color="#f59e0b" /> BONUS
          </div>
          {bonusQuests.map(q => <QuestCard key={q.id} q={q} accentColor="#f59e0b" />)}
        </>}

        {/* ─── STATS ─── */}
        {page === "stats" && <>
          <div style={{ textAlign: "center", margin: "18px 0 24px" }}>
            <h2 style={{ fontFamily: "'Cinzel', serif", fontWeight: 900, fontSize: "1.5rem", color: rank.color, letterSpacing: "0.14em", textShadow: `0 0 24px ${rank.glow}`, margin: 0 }}>
              STATISTIQUES
            </h2>
          </div>

          <div style={{
            ...card, textAlign: "center", padding: 28,
            background: `linear-gradient(145deg, ${rank.color}0a, transparent)`, borderColor: `${rank.color}20`,
          }}>
            <div style={{ fontSize: "3.2rem", fontFamily: "'Cinzel', serif", fontWeight: 900, color: rank.color, textShadow: `0 0 30px ${rank.glow}` }}>
              {totalPower}
            </div>
            <div style={{ fontSize: "0.8rem", color: "#7a7aa0", letterSpacing: "0.12em", marginTop: 2 }}>PUISSANCE TOTALE</div>
            <div style={{ fontSize: "0.85rem", color: rank.color, marginTop: 6, fontFamily: "'Cinzel', serif", letterSpacing: "0.08em" }}>{rank.label}</div>
          </div>

          {data.sp > 0 && (
            <div style={{
              ...card, textAlign: "center", padding: 14,
              background: "#f59e0b0c", borderColor: "#f59e0b33",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
            }}>
              <Icons.Star size={18} color="#f59e0b" />
              <span style={{ fontSize: "0.88rem", color: "#f59e0b", fontWeight: 700, letterSpacing: "0.08em" }}>
                {data.sp} POINTS DE STAT DISPONIBLES
              </span>
            </div>
          )}

          {STATS_META.map(({ key, name, IconComp }) => {
            const val = data.stats[key];
            const maxVal = Math.max(...Object.values(data.stats), 10);
            const pct = val / (maxVal * 1.2);
            return (
              <div key={key} style={{ ...card, display: "flex", alignItems: "center", gap: 14, padding: 16 }}>
                <div style={{
                  width: 48, height: 48, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center",
                  background: `${rank.color}10`, border: `1px solid ${rank.color}18`,
                }}>
                  <IconComp size={24} color={rank.color} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 7 }}>
                    <span style={{ fontWeight: 600, fontSize: "0.88rem", letterSpacing: "0.06em", color: "#b0b0cc" }}>{name}</span>
                    <span style={{ color: rank.color, fontWeight: 700, fontSize: "1.15rem", fontFamily: "'Cinzel', serif" }}>{val}</span>
                  </div>
                  <div style={{ height: 6, borderRadius: 3, background: "#ffffff08", overflow: "hidden" }}>
                    <div style={{
                      height: "100%", borderRadius: 3, width: `${pct * 100}%`,
                      background: `linear-gradient(90deg, ${rank.color}77, ${rank.color})`,
                      boxShadow: `0 0 6px ${rank.color}44`, transition: "width 0.6s ease",
                    }} />
                  </div>
                </div>
                {data.sp > 0 && (
                  <button onClick={() => allocStat(key)} style={{
                    width: 40, height: 40, borderRadius: 10, border: `1px solid ${rank.color}33`, cursor: "pointer",
                    background: `${rank.color}12`, display: "flex", alignItems: "center", justifyContent: "center",
                    transition: "background 0.15s",
                  }}
                    onMouseEnter={e => e.currentTarget.style.background = `${rank.color}28`}
                    onMouseLeave={e => e.currentTarget.style.background = `${rank.color}12`}
                  >
                    <Icons.Plus size={18} color={rank.color} />
                  </button>
                )}
              </div>
            );
          })}

          <div style={{ ...card, padding: 20 }}>
            <div style={{ fontFamily: "'Cinzel', serif", fontWeight: 700, marginBottom: 14, letterSpacing: "0.06em" }}>Résumé</div>
            {[
              ["Niveau", data.level],
              ["XP Total", data.xp.toLocaleString()],
              ["Quêtes Complétées", data.totalDone],
              ["Rang", rank.label],
            ].map(([l, v]) => (
              <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "7px 0", borderBottom: "1px solid #ffffff06", fontSize: "0.85rem" }}>
                <span style={{ color: "#7a7aa0" }}>{l}</span>
                <span style={{ fontWeight: 700, color: rank.color }}>{v}</span>
              </div>
            ))}
          </div>
        </>}

        {/* ─── TITLES ─── */}
        {page === "titles" && <>
          <div style={{ textAlign: "center", margin: "18px 0 24px" }}>
            <h2 style={{ fontFamily: "'Cinzel', serif", fontWeight: 900, fontSize: "1.5rem", color: rank.color, letterSpacing: "0.14em", textShadow: `0 0 24px ${rank.glow}`, margin: 0 }}>
              TITRES
            </h2>
          </div>
          <div style={{ textAlign: "center", marginBottom: 20, fontSize: "0.85rem", color: "#7a7aa0" }}>
            {ACHIEVEMENTS.filter(a => a.cond({ total: data.totalDone, ri, stats: data.stats })).length} / {ACHIEVEMENTS.length} débloqués
          </div>
          {ACHIEVEMENTS.map(a => {
            const unlocked = a.cond({ total: data.totalDone, ri, stats: data.stats });
            const IC = a.IconComp;
            return (
              <div key={a.id} style={{
                ...card, display: "flex", alignItems: "center", gap: 14,
                opacity: unlocked ? 1 : 0.3,
                borderColor: unlocked ? `${rank.color}28` : "#ffffff06",
                background: unlocked ? `linear-gradient(145deg, ${rank.color}08, transparent)` : "#ffffff03",
              }}>
                <div style={{
                  width: 50, height: 50, borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center",
                  background: unlocked ? `${rank.color}15` : "#ffffff06",
                  border: `1px solid ${unlocked ? rank.color + "30" : "#ffffff08"}`,
                }}>
                  {unlocked ? <IC size={26} color={rank.color} /> : <Icons.Lock size={22} color="#555" />}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: "0.95rem", fontFamily: "'Cinzel', serif", letterSpacing: "0.04em" }}>{a.name}</div>
                  <div style={{ fontSize: "0.8rem", color: "#7a7aa0", marginTop: 3 }}>{a.desc}</div>
                </div>
                {unlocked && <Icons.Check size={18} color={rank.color} />}
              </div>
            );
          })}
        </>}
      </main>

      {/* Bottom Nav */}
      <nav style={{
        position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 100,
        background: "linear-gradient(180deg, transparent 0%, #08081acc 25%, #08081af2 100%)",
        paddingTop: 14, paddingBottom: "max(14px, env(safe-area-inset-bottom))",
      }}>
        <div style={{ display: "flex", justifyContent: "space-around", maxWidth: 540, margin: "0 auto" }}>
          {navItems.map(({ id, label, Ic }) => {
            const active = page === id;
            return (
              <button key={id} onClick={() => setPage(id)} style={{
                display: "flex", flexDirection: "column", alignItems: "center", gap: 3,
                background: "none", border: "none", cursor: "pointer", padding: "6px 18px",
                color: active ? rank.color : "#555570", transition: "color 0.2s",
              }}>
                <Ic size={22} color={active ? rank.color : "#555570"} />
                <span style={{ fontSize: "0.62rem", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" }}>{label}</span>
                {active && (
                  <div style={{
                    width: 5, height: 5, borderRadius: "50%", background: rank.color,
                    boxShadow: `0 0 8px ${rank.color}`, marginTop: 1,
                  }} />
                )}
              </button>
            );
          })}
        </div>
      </nav>

      <style>{`
        @keyframes fadeIn { from { opacity: 0 } to { opacity: 1 } }
        @keyframes popIn { from { transform: scale(0.4); opacity: 0 } to { transform: scale(1); opacity: 1 } }
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        input[type=number] { -moz-appearance: textfield; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #ffffff12; border-radius: 2px; }
        body { background: #08081a; }
      `}</style>
    </div>
  );
}
